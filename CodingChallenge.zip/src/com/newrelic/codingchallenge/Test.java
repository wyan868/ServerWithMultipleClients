package com.newrelic.codingchallenge;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Tests server with multiple clients.
 */
public class Test {
    private static final Logger LOGGER = Logger.getLogger(Test.class.getName());
	private static MyServer server = MyServer.getInstance();
	private static Timer timer = new Timer();
	private static List<MyClient> clients = new ArrayList<MyClient>();

	/*
	 * @param args This server allows at most 5 connections.  These arguments are the input file paths, 
	 * one for each client.  There should be at least 1 argument and at most 5 arguments.
	 */
	public static void main(String[] args) throws IOException {
		String host = PropertyLoader.getProp().getProperty(PropertyLoader.HOST);
		int port = Integer.valueOf(PropertyLoader.getProp().getProperty(PropertyLoader.PORT));
		int maxConnections = Integer.valueOf(PropertyLoader.getProp().getProperty(PropertyLoader.MAX_CONN));
		
		int length = args.length;
		
		if (length > maxConnections) {
			System.out.println("At most " + maxConnections + " clients are allowed.");
			System.exit(1);
		}
		
		if (length < 1) {
			System.out.println("Please provide the input file path.");
			System.exit(1);
		}
		
		server.start();
		timer.schedule(server, 0, 10000); // print the report every 10 second
		
		for (int i = 0; i < length; i++) {
			try {
				MyClient client = new MyClient(host, port, args[i]);
				client.run();
				clients.add(client);
			} catch (ClientSocketException e) {
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
				close(true);
			} 
		}
		
		close(false);
	}
	
	private static void close(boolean isForced) {
		boolean allClientsOff = true;
		for (MyClient client : clients) {
			client.close();
			allClientsOff = allClientsOff && !client.isConnected();
		}
		
		if (!allClientsOff) {
			isForced = false;
		}
		
		server.shutdown(isForced);
		timer.cancel();
	}
}
