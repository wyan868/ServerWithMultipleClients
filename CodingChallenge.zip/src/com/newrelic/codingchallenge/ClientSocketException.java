package com.newrelic.codingchallenge;

public class ClientSocketException extends RuntimeException {	   
	private static final long serialVersionUID = 1L;

	public ClientSocketException(String message, Throwable t){
	       super(message, t);
	   }
	}