package com.newrelic.codingchallenge;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyLoader {
	public static String HOST = "host";
	public static String PORT = "port";
	public static String MAX_CONN = "max_connection";
	public static String OUTPUT_FILE_PATH = "output_file_path";
	
	public static Properties getProp() throws IOException {
		FileInputStream fis = null;
		Properties prop = null;
		try {
			fis = new FileInputStream("src/resources/config.properties");
			prop = new Properties();
			prop.load(fis);
		} catch(FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		} finally {
			fis.close();
		}
		return prop;
	}
}
