package com.newrelic.codingchallenge;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This socket client reads a .txt file and writes to the server
 * 
 * @author Wei Yan
 */
public class MyClient {

    private static final Logger LOGGER = Logger.getLogger(MyClient.class.getName());

    private Socket client;
    private BufferedReader input;
    private BufferedWriter toServer;
    private boolean isConnected;
    
    private static final int TIMEOUT = 20000;           

    /*
     * Constructs a client socket instance.
     */
    public MyClient(String host, int port, String inputFilePath) {
        create(host, port, inputFilePath);
    }

    /* Creates a client socket with a timeout until MAX_RETRY is reached.  
     * 
	 * @param inputFilePath The input file should be a text file.  Each line must either be composed of exactly 
	 * nine decimal digits (e.g.: 314159265 or 007007009) immediately followed by a server-native newline sequence; 
	 * or the word "terminate".
     */
    private void create(String host, int port, String inputFilePath) {
        try {        	
                SocketAddress socketAddress = new InetSocketAddress(host, port);
                client = new Socket();

                LOGGER.log(Level.INFO, "Connecting to server on port " + port); 
                client.connect(socketAddress, TIMEOUT);
                isConnected = true;
                client.setSoTimeout(TIMEOUT);
                client.setTcpNoDelay(true);
                client.setKeepAlive(true);
                
                input = new BufferedReader(new FileReader(inputFilePath));
                toServer = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        } catch (IOException e) {
        	String msg = "The client socket is not created.";
            LOGGER.log(Level.SEVERE, msg, e);
            close();
        }
    }

    /*
     *  Read the input file line by line and write to the server. 
     */
    public void run() {
        try {
        	if (toServer != null) {
	        	String line = null;
	        	while ((line = input.readLine()) != null) {	        		
	        		boolean isNineDigitNumber = line.matches("[0-9]+") && (line.length() == 9);
	        		if (line.equalsIgnoreCase("terminate") || isNineDigitNumber) {
		        		toServer.write(line);
		        		toServer.newLine();
	        		}
	        		else {
	        			toServer.flush();
	        			close();
	        			break;
	        		}
	        	}
	        	
	        	// This is necessary because it could be forced to get disconnected when bad data is read in
	        	if (toServer != null) {
	        		toServer.flush();
	        	}
	        	// close when the job is done
	        	close();
        	}
        } catch(IOException e) {
        	String msg = "The client socket stops running.";
            LOGGER.log(Level.SEVERE, msg, e);
            throw new ClientSocketException(msg,e);
        } 
    }

    /*
     *  Closes the socket
     */
    public void close() {
        if (client != null) {
            try {
            	if (toServer != null) {toServer.close();}
            	if (input != null) {input.close();}
                client.close();
	        	isConnected = false;
            } catch (IOException e) {
                LOGGER.log(Level.WARNING, "The client socket cannot be closed correctly.", e);
            } finally {
            	input = null;
            	toServer = null;
                client = null;
            }
        }
    }
    
    /*
     * Returns this client socket is connected to the server or not 
     */
    public boolean isConnected() {
    	return isConnected;
    }
}
