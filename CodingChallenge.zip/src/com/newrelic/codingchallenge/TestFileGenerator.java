package com.newrelic.codingchallenge;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* Generates a text file which contains 2,000,000 9-digit numbers
 * 
 * @author Wei Yan
 */
public class TestFileGenerator {
    private static final Logger LOGGER = Logger.getLogger(TestFileGenerator.class.getName());
    
	public static void generate(String filePath) {
		BufferedWriter toFile;
		try {
			toFile = new BufferedWriter(new FileWriter(filePath));
			int count = 0;
			while (count < 2000000) {
		        long timeSeed = System.nanoTime(); // to get the current date time value		
		        double randSeed = Math.random() * 1000; // random number generation		
		        long midSeed = (long) (timeSeed * randSeed); // mixing up the time and rand number.
		        String s = midSeed + "";
		        if (s.length() > 9) {
			        String subStr = s.substring(0, 9);
			        toFile.write(subStr);
			        toFile.newLine();
			        count++;
		        }
			}	
			toFile.close();
		} catch (IOException e) {
            LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}
	
	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			generate(args[i]);
		}
	}
}
