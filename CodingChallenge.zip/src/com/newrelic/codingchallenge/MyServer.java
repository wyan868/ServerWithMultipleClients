package com.newrelic.codingchallenge;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * This server socket receives input from at most 5 client sockets and print a report 
 * every 10 seconds to standard output.
 * 
 * @author Wei Yan
 */
public class MyServer extends TimerTask {
    private static final Logger LOGGER = Logger.getLogger(MyServer.class.getName());
    
    private static MyServer instance;
    
    private ServerSocket serverSocket;
    private ExecutorService executor;
    private int maxConnections;
    private boolean isServerOn;
    private BufferedWriter toFile;    
    private Set<Integer> numbers;
    private int uniqueNumberCount, duplicateNumberCount, totalCount;
    
    private MyServer() {}

    /*
     *  Gets the instance of the server socket
     */
    public static MyServer getInstance() {
        if ((instance == null) || !instance.isServerOn) {
            create();
        } 
        return instance;
    }

    /*
     *  Creates the server socket instance
     */
    private synchronized static void create() {
        try {
            instance = new MyServer();
            instance.maxConnections = Integer.valueOf(PropertyLoader.getProp().getProperty(PropertyLoader.MAX_CONN));
            int port = Integer.valueOf(PropertyLoader.getProp().getProperty(PropertyLoader.PORT));
            String outputFilePath = PropertyLoader.getProp().getProperty(PropertyLoader.OUTPUT_FILE_PATH);
            instance.serverSocket = new ServerSocket(port);
            instance.executor = Executors.newFixedThreadPool(instance.maxConnections);
            instance.isServerOn = true;
            instance.numbers = new HashSet<Integer>();  
            instance.toFile = new BufferedWriter(new FileWriter(outputFilePath));
            instance.uniqueNumberCount = 0;
            instance.duplicateNumberCount = 0;
        } catch (IOException e) {
        	String msg = "The server socket cannot be created correctly.";
            LOGGER.log(Level.SEVERE, msg, e);
            throw new RuntimeException(msg);
        }
    }
    
    /*
     * Starts the server socket.  Creates one thread of each client socket.
     */
    public void start() {
        LOGGER.log(Level.INFO, "Starting socket server");
        
        //Create one thread for each client 
        for (int i = 0; i < maxConnections; i++) {
            Runnable runnable = () -> {
                try {
                    Socket clientSocket = serverSocket.accept();
                    LOGGER.log(Level.INFO, "Just connected to " + clientSocket.getRemoteSocketAddress());
                    
                    BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                	String line = null;
                	while ((line = input.readLine()) != null) {
        	            if (!line.equalsIgnoreCase("terminate")) {
                    		totalCount++;
        	            	int number = Integer.parseInt(line);
        	            	if (!numbers.contains(number)) {
        	            		numbers.add(number);
                	            this.toFile.write(line);
                	            this.toFile.newLine();
                	            uniqueNumberCount++;
        	            	}  
        	            	else {
        	            		duplicateNumberCount++;
        	            	}
        	            }
        	            else {
        	            	shutdown(true);
        	            	break;
        	            }
                	}
                } catch (IOException e) {
                    //LOGGER.log(Level.SEVERE, e.getMessage(), e);
                } 
            };
            executor.execute(runnable);
        }
    }
    
    /*
     * Shuts down the server socket
     */
    public void shutdown(boolean isForced) {
        LOGGER.log(Level.INFO, "Shutting down the server ...");
        try {
        	if (!isForced) {
        		// wait for all clients to close
        		Thread.sleep(5000);
        	}
        	if (isServerOn) {
        		toFile.flush();
        		toFile.close();
	            serverSocket.close();
	            executor.shutdownNow();
	        }
        } catch (IOException | InterruptedException ex) {
             LOGGER.log(Level.INFO, "The server doesn't shut down properly.", ex);
        } finally {
        	toFile = null;
            isServerOn = false;
            serverSocket = null;
            executor = null;
            LOGGER.log(Level.INFO, "The server shuts down.");
            cancel(); // cancel the scheduled work
            System.out.println("Unique total: " + numbers.size() + ".  " + totalCount + " numbers counted."); 
            System.exit(0);
        }
    }
    
    /*
     * @override
     * @see java.util.TimerTask#run()
     */
    public void run() {
        System.out.println("Received " + uniqueNumberCount + " unique numbers, " + duplicateNumberCount + 
        		" duplicates.  Unique total: " + numbers.size() + ". " + totalCount + " numbers counted"); 
        uniqueNumberCount = 0;
        duplicateNumberCount = 0;
    } 
}