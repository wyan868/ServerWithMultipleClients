﻿Server with multiple clients on TCP/IP

Author: Wei Yan

This executable jar file contains a server that opens a socket and 
restricts input to at most 5 concurrent clients.  Clients will connect to 
the Application and write any number of 9 digit numbers, and then close 
the connection.  The input file should be a text file.  Each line must 
either be composed of exactly nine decimal digits (e.g.: 314159265 or 
007007009) immediately followed by a server-native newline sequence; or 
the word "terminate".  Any data that does not conform to a valid line of 
input are discarded and the client connection terminates immediately and 
without comment.  

The server writes numbers provided by the clients to a file named 
“numbers.log” or another user-defined file.  No duplicates are allowed.  
Every 10 seconds, the Application prints a report to standard output:
• The difference since the last report of the count of new unique numbers 
that have been received.
• The difference since the last report of the count of new duplicate 
numbers that have been received.
• The total number of unique numbers received for this run of the 
Application.
Example report: Received 50 unique numbers, 2 duplicates. Unique total: 
567231

The following parameters can be defined in the config.properties file:

host=127.0.0.1
port=4000
max_connection=5
output_file_path=C:/temp/numbers.log

To run the application, open a command line and follow this syntax:

java -cp CodingChallenge.jar com.newrelic.codingchallenge.Test 
input_file_path1 input_file_path2 …

For example, 

java -cp CodingChallenge.jar com.newrelic.codingchallenge.Test 
C:/temp/input1.txt C:/temp/input2.txt C:/temp/input3.txt

There should be at least 1 argument and at most 5 arguments.  These 
arguments are the input file paths, one for each client.  

There is also a TestFileGenerator.java in the jar.  This is used to 
generate text data file.  Each contains 2,000,000 randomly-created 9-
digit numbers.  These files can be used as the inputs to this Application.  
To run it, open a command line and follow this syntax:

java -cp CodingChallenge.jar 
com.newrelic.codingchallenge.TestFileGenerator output_file_path1 
output_file_path2 …

For example, 

java -cp CodingChallenge.jar 
com.newrelic.codingchallenge.TestFileGenerator C:/temp/input1.txt 
C:/temp/input2.txt C:/temp/input3.txt C:/temp/input4.txt

It takes as many arguments as needed so that it can generate as many test 
input files as needed.
